package ejercicio1;

public enum TipoEnfermedad {
    Hipertension,
	Cardiopatia,
	Insuficiencia,
	Cardiaca
}
