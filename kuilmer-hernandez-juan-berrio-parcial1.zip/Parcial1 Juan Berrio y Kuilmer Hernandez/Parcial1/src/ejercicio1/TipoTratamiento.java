package ejercicio1;

public enum TipoTratamiento {
    Medicamentos,
	Cirugia,
	Terapia
}
