package ejercicio1;

public enum EstadoPaciente {
    Tratamiento,
	En_Remision, 
	Hospitalizacion
}
