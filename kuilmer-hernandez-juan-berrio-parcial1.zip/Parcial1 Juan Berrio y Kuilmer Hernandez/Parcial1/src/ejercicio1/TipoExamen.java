package ejercicio1;

public enum TipoExamen {
    Electrocardiograma,
	RayosX,
	Cateterismo,
	Holter
}
