package ejercicio1;

public enum GeneroPaciente {
    Mujer,
	Hombre,
}
